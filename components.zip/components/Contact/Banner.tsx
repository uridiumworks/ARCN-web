const Banner =() => {
    return (
        <main className="bg-black text-white font-montserrat text-center pb-20 place-content-center h-[230px]">
            <h1 className="font-extrabold text-4xl">CONTACT US</h1>
        </main>
    )
}

export default Banner;