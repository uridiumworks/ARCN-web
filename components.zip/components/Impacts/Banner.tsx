import "./styling.css"
const Banner = () => {

    return ( 
        <main className="w-full picker h-[350px] place-content-center text-center font-montserrat">
            <div className="w-full h-[350px] opacity-25 flex justify-center items-center"></div>
        </main>
    );
}
 
export default Banner;