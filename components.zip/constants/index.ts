export const topNav = ["Resources & Downloads", "Governance", "Publications", "Careers", "Contact"]

export const mainNav = ["Home", "About Us", "mandate", "News & Events", "Programs & Projects", "Impacts"]