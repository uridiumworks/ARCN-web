const SignUp = () => {
    return ( 
        <main></main>
     );
}
 
export default SignUp;