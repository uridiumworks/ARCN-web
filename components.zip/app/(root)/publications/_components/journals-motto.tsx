import React from 'react'

const JournalsMotto = () => {
  return (
    <div className='w-full font-montserrat bg-black flex justify-center items-center py-28'>
    <div className="text-center">
        <h1 className="text-5xl font-bold text-white">Journal</h1>
    </div>
</div>
  )
}

export default  JournalsMotto

