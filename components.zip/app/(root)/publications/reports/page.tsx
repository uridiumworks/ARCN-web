import React from 'react'
import Reports from '../_components/reports'

const ReportsPage = () => {
  return (
    <div>
        <Reports/>
    </div>
  )
}

export default ReportsPage