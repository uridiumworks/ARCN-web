import React from 'react'
import FundingMotto from '../_components/fundingMotto'
import Text from '../_components/text'

const Newsletters = () => {
  return (
    <div>
        <FundingMotto/>
        <Text/> 
    </div>
  )
}

export default Newsletters