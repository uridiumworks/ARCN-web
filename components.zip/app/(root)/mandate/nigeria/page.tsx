import Key from "@/components/Mandate/Mandate/Institutes/Key";
import Who from "@/components/Mandate/Mandate/Institutes/Who";

const Nigeria = () => {
    return (
        <main>
            <Who />
            <Key />
        </main>
    )
}

export default Nigeria;