const College = () => {
    return (
        <main>
            nancy
        </main>
    )
}

export default College;