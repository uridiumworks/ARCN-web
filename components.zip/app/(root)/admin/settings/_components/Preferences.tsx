"use client"
import React from 'react'

const Preferences = () => {
  return (
    <div className="px-10 py-3">Preferences</div>
  )
}

export default Preferences