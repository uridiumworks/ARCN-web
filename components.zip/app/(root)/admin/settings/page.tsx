import React from 'react'
import SettingsPage from './SettingsPage'

const Settings = () => {
  return (
    <SettingsPage/>
  )
}

export default Settings