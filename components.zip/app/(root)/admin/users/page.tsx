import React from 'react'
import Users from './Users'

const UsersPage = () => {
  return (
    <Users/>
  )
}

export default UsersPage