




export type UsersTableType = {
    fullName: string;
    email: string;
    phoneNumber: string;
    role: string;
    dateCreated: string;
  };