"use client";

import React from 'react'
import NewsletterView from './NewsletterView'

const NewsLetter = () => {
  return (
    <><NewsletterView/></>
  )
}

export default NewsLetter