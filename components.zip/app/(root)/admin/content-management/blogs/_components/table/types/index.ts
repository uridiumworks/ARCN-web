


export type ContentManagementBlogsTableType = {
    checkbox: any;
    title: string;
    authorName: string;
    dateCreated: string;
    authorEmail: string;
    authorPhoneNumber: string;
    action: any;
  };