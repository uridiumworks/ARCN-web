import React from 'react'
import ContentMgtBlogView from './ContentMgtBlogView'

const Blogs = () => {
    return (
        <><ContentMgtBlogView /></>
    )
}

export default Blogs