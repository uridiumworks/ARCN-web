import React from 'react'
import JournalView from './JournalView'

const Journals = () => {
  return (
    <><JournalView/></>
  )
}

export default Journals