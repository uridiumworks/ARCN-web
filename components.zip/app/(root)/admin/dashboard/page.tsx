
import React from 'react'
import ViewBlogDashboard from './ViewBlogDashboard'



const AdminDashboard = () => {
    return (
        <>
            <ViewBlogDashboard />
        </>
    )
}

export default AdminDashboard