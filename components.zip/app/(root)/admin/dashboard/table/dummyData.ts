

export const data = [
    {
        title: "Aggression",
        authorName: "Collins Rollins",
        dateCreated: "24 july 2016",
        authorEmail: "Roolins19@gmail.com",
        authorPhoneNumber: "09024343853",
        action: ""
    }
]