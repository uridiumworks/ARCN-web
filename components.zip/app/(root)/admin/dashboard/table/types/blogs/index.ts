


export type BlogsTableType = {
    title: string;
    authorName: string;
    dateCreated: string;
    authorEmail: string;
    authorPhoneNumber: string;
    action: any;
  };