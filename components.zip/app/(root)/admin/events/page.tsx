import React from 'react'
import EventPageViewComponent from './EventPageViewComponent'

const EventsPageView = () => {
  return (
    <EventPageViewComponent/>
  )
}

export default EventsPageView