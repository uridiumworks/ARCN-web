

export type EventTableType = {
    checkbox: any;
    subject: string;
    description: string;
    eventDate: string;
    eventTime: string;
    venue: string;
    action: any;
  };