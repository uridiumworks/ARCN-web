
import React from 'react'
import AdminDashboard from './dashboard/page'



const Admin = () => {
    return (
        <>
            <AdminDashboard/>
        </>
    )
}

export default Admin