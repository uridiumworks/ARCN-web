



export type NarisTableType = {
    checkbox: any;
    institutionName: string;
    establishDate: string;
    joinDate: string;
    website: string;
    action: any;
  };


export type CordinationReportTableType = {
    checkbox: any;
    title: string;
    publisherName: string;
    authorEmail: string;
    publishDate: string;
    action: any;
  };