

export type ProjectsTableType = {
    checkbox: any;
    title: string;
    instituteName: string;
    dateCreated: string;
    action: any;
  };

  export type ProgramsTableType = {
    checkbox: any;
    subject: string;
    description: string;
    eventDate: string;
    eventTime: string;
    venue: string;
    action: any;
  };