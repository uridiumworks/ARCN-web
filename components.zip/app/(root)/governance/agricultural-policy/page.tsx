import React from 'react'
import AgriculturalPolicy from '../_components/agricultural-policy'

const AgriculturalPolicyPage = () => {
  return (
    <div>
        <AgriculturalPolicy/>
        </div>
  )
}

export default AgriculturalPolicyPage