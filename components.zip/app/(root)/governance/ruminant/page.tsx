import React from 'react'
import Ruminant from '../_components/ruminant'

const RuminantPage = () => {
  return (
    <div><Ruminant/></div>
  )
}

export default RuminantPage