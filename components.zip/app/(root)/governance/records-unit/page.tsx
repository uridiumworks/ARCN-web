import React from 'react'
import RecordsUnit from '../_components/records-unit'

const RecordsUnitPage = () => {
  return (
    <div>
        <RecordsUnit/>
    </div>
  )
}

export default RecordsUnitPage