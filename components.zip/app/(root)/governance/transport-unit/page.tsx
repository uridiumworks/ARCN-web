import React from 'react'
import TransportUnit from '../_components/transport-unit'

const TransportUnitPage = () => {
  return (
    <div>
        <TransportUnit/>
    </div>
  )
}

export default TransportUnitPage