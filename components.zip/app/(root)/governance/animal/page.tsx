import React from 'react'
import Animal from '../_components/animal'

const AnimalPage = () => {
  return (
    <div><Animal/></div>
  )
}

export default AnimalPage