import React from 'react'
import AgriculturalBusiness from '../_components/agricultural-business'

const AgriculturalBusinessPage = () => {
  return (
    <div><AgriculturalBusiness/></div>
  )
}

export default AgriculturalBusinessPage