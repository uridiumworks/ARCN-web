import React from 'react'
import MaintenanceUnit from '../_components/maintenance-unit'

const MaintenanceUnitpage = () => {
  return (
    <div><MaintenanceUnit/></div>
  )
}

export default MaintenanceUnitpage