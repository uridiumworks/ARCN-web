import React from 'react'
import Livestock from '../_components/livestock'

const LivestockPage = () => {
  return (
    <div><Livestock/></div>
  )
}

export default LivestockPage