import React from 'react'
import SecurityUnit from '../_components/security-unit'

const SecurityUnitPage = () => {
  return (
    <div><SecurityUnit/></div>
  )
}

export default SecurityUnitPage