import AccountUnit from '../_components/account-unit'

const AccountUnitPage = () => {
    return (
      <div><AccountUnit/></div>
    )
  }
  
  export default AccountUnitPage;