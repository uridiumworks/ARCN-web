import React from 'react'
import AgriculturalExtensions from '../_components/agricultural-extensions'

const AgriculturalExtensionspage = () => {
  return (
    <div><AgriculturalExtensions/></div>
  )
}

export default AgriculturalExtensionspage