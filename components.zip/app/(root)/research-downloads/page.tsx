import React from 'react'

const Research = () => {
  return (
    <div>
      
    </div>
  )
}

export default Research
