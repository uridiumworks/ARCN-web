import Collection from "@/components/NewsandEvents/News/Collection";
import New from "@/components/NewsandEvents/News/New";
import Upcoming from "@/components/NewsandEvents/News/Upcoming";
import Journal from "@/components/Shared/Journal";
import CustomContainer from "@/components/CustomContainer";

const NewsandEvents = () => {

    return ( 
        <main>
            <Collection />
            <CustomContainer>
                <New />
                <Upcoming/>
            </CustomContainer>
            <Journal />
        </main>
    );
}
 
export default NewsandEvents;